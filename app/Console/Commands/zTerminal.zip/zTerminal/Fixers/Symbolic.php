<?php

namespace App\Console\Commands\zTerminal;

use Illuminate\Console\Command;
use ZipArchive;
use Illuminate\Support\Facades\Http;
use File;
use Lazzard\FtpClient\Connection\FtpSSLConnection;
use Lazzard\FtpClient\Config\FtpConfig;
use Lazzard\FtpClient\FtpClient;

class Symbolic extends Command
{


    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'symbolic {action}';
    public $host_url, $ftp_host, $ftp_user, $ftp_password, $ftp_port, $ftp_folder, $host;
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'It deploy code in the specified server and make backup files available';

    public function handle()
    {
        $retry = 0;
        // try {
            $this->host_url = "####URL####";
            $this->ftp_host = "####HOST####";
            $this->ftp_user = "####USERNAME####";
            $this->ftp_password = "####PASSWORD####";
            $this->ftp_port = "####PORT####";
            $this->ftp_folder = 'files';
    
            $ftp_core_folder = "####CORE_FOLDERS####";
            $project_directory = "####PROJECT_DIRECTORY_PATH####";
            $local_project_directory = "####LOCAL_PROJECT_DIRECTORY_PATH####";


        if (!extension_loaded('ftp')) {
            throw new \RuntimeException("FTP extension not loaded.");
        }


        ini_set('maximum_execution_time', 2500);
        // echo "Starting... \n";

        //     echo "
        // Htaccess.....
        //   ";

        echo "\n";
        echo "\n";

        // echo "Establishing FTP connection... \n";
        $connection = new FtpSSLConnection($this->ftp_host, $this->ftp_user, $this->ftp_password);
        $connection->open();

        $config = new FtpConfig($connection);
        $config->setPassive(true);

        $client = new FtpClient($connection);

        if ($connection) {
            // echo "Local folders ready.\n";

            $this->info("FTP Connected. Running...");


         

            sleep(5);
            // $this->info("ZIP Created");
           
            $this->info('Checking Configuration');

            // Check is Core File
            // Goto Core

            switch ($this->argument('action')) {
                case 'l':
                     $output = shell_exec("cd " . $local_project_directory . " && " . ' php artisan storage:link');
                      echo $output;
                      shell_exec("cd ..");
                    break;
                case 'r':
                       $content = $this->contentData($ftp_core_folder);
                        $zTerminalFolderPath = base_path('storage/app/zterminal');
                        $folderPath = base_path('storage/app/zterminal/payloads');
                    
                    // Check if the zterminal folder exists, if not, create it
                    if (!is_dir($zTerminalFolderPath)) {
                        mkdir($zTerminalFolderPath, 0755, true);
                    }
                    
                    // Check if the payloads folder exists, if not, create it
                    if (!is_dir($folderPath)) {
                        mkdir($folderPath, 0755, true);
                    }

                    
                        $this->createFileInLocalDirectory($content['filename'], $content['content'], $folderPath);
                    

                        $local_file_path = $folderPath . '/' . $content['filename'];
                        $local_file_size = filesize($local_file_path);
                        $file_size_MB = round($local_file_size / 1024 / 1024, 2);
                        $file_size_formatted = '';

                    if ($file_size_MB >= 1) {
                        $file_size_formatted = $file_size_MB . "MB";
                    } elseif ($file_size_KB = round($local_file_size / 1024, 2)) {
                        $file_size_formatted = $file_size_KB . "KB";
                    } else {
                        $file_size_formatted = $local_file_size . "B";
                    }

                        echo 'INFO: Size ' . $file_size_formatted . '. Starting Code Upload' . PHP_EOL;

                        $remote_local_file_path = basename($local_file_path);

                        $client->upload($local_file_path, $remote_local_file_path);

                        $connection->close();
                        
                         echo $this->host_url . 'symbolic.php';
                        $response = Http::withOptions([
                            'verify' => false,
                        ])->get($this->host_url . 'symbolic.php');

                        echo "\n $response \n";
                        
                      
                    break;
               
                default:
                    break;
            }
            return Command::SUCCESS;
        } else {
            $this->error('Failed to connect to FTP server.');
        }
    }
    
    
    private function contentData($ftp_core_folder)
    {
        $filename = 'symbolic.php';  // Change the filename as needed
        $content = '<?php
        $targetFolder = __DIR__ . \'/../\' . $ftp_core_folder . \'/storage/app/public/\';
        $linkFolder = __DIR__ . \'/storage\';

        // Uncomment the following lines for debugging
        // echo $targetFolder . "\n";
        // echo $linkFolder;
        // return;

        // Check if the target folder exists
        if (!is_dir($targetFolder)) {
            echo \'Error: Target folder does not exist\';
            return;
        } 

        // Check if there is no existing symlink or file at the destination
        if (file_exists($linkFolder)) {
            echo \'Error: Symlink or file already exists at the destination\';
            return;
        }

        // Create symbolic link and store the result in $link
        $link = symlink($targetFolder, $linkFolder);

        // Check the result and provide feedback
        if ($link !== false) {
            echo \'Symlink process successfully completed\';
        } else {
            echo \'Symlink process failed\';
        }
        ?>';

        return ['filename'=> $filename, 'content' => $content];
    }

    private function createFileInLocalDirectory($filename, $content, $folderPath)
    {
            $filePath = $folderPath . '/' . $filename;

            // Check if the file already exists
        if (file_exists($filePath)) {
            echo "Error: File '$filename' already exists in the directory\n";
            return;
        }

            // Create the file and write content
            $result = file_put_contents($filePath, $content);

            // Check the result and provide feedback
        if ($result !== false) {
            echo "File '$filename' successfully created in the directory";
        } else {
            echo "Error: Failed to create file '$filename'";
        }
    }
}
