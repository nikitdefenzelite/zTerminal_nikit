<?php

namespace App\Console\Commands\zTerminal;

use Illuminate\Console\Command;
use ZipArchive;
use Illuminate\Support\Facades\Http;
use File;
use Lazzard\FtpClient\Connection\FtpSSLConnection;
use Lazzard\FtpClient\Config\FtpConfig;
use Lazzard\FtpClient\FtpClient;

class Deployer extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'deploy';
    public $host_url, $ftp_host, $ftp_user, $ftp_password, $ftp_port, $ftp_folder, $host;
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'It deploy code in the specified server and make backup files available';

    public function handle()
    {


        $compression_type = "tar";

        $retry = 0;
        // try {
        $this->host_url = "####URL####";
        $this->ftp_host = "####HOST####";
        $this->ftp_user = "####USERNAME####";
        $this->ftp_password = "####PASSWORD####";
        $this->ftp_port = "####PORT####";
        $this->ftp_folder = 'files';

        $ftp_core_folder = "####CORE_FOLDERS####";
        $server_project_directory = "####PROJECT_DIRECTORY_PATH####";
        $local_project_directory = "####LOCAL_PROJECT_DIRECTORY_PATH####";
       
    

         $ftp_debug = true;

        // $local_folders = explode(',', env('FTP_LOCAL_FOLDERS'));
         $local_folders = ['app','resources','config'];

        if (!extension_loaded('ftp')) {
            throw new \RuntimeException("FTP extension not loaded.");
        }

        ini_set('maximum_execution_time', 2500);
        if ($ftp_debug) {
            echo "Starting... \n";
        }

        //     echo "
        //         _____             _
        //        |  __ \           | |
        //     ___| |  | | ___ _ __ | | ___  _   _  ___ _ __
        //    |_  / |  | |/ _ \ '_ \| |/ _ \| | | |/ _ \ '__|
        //     / /| |__| |  __/ |_) | | (_) | |_| |  __/ |
        //    /___|_____/ \___| .__/|_|\___/ \__, |\___|_|   v1.0.0 beta
        //                    | |             __/ |
        //                    |_|            |___/
        //   ";

        if ($ftp_debug) {
            echo "\n";
        }
        if ($ftp_debug) {
            echo "\n";
        }


        if ($ftp_debug) {
            echo "Establishing Connection... \n";
        }
        $connection = new FtpSSLConnection($this->ftp_host, $this->ftp_user, $this->ftp_password);
        $connection->open();

        $config = new FtpConfig($connection);
        $config->setPassive(true);

        $client = new FtpClient($connection);

        if ($connection) {
            if ($ftp_debug) {
                echo "Local folders ready.\n";
            }
 
            $backup_folder = 'zterminal/zips/';

            $this->info("Server Connected. Running...");

            $zip_name = 'deploy_container.zip';
            $tar_name = 'deploy_container';

            if ($compression_type == "tar") {
                $zip_path = $this->makeTar($local_folders, $tar_name, $local_project_directory, $ftp_debug);
            } else {
                $zip_path = $this->makeZip($local_folders, $backup_folder, $zip_name,$local_project_directory);
            }


            sleep(5);
            $local_file_size = filesize($zip_path);


            if (!$client->isDir('zterminal')) {
                $client->createDir('zterminal');
                $client->changeDir('zterminal/');

                if (!$client->isDir('zbackups')) {
                    $client->createDir('zbackups');
                }
                if (!$client->isDir('zcontainers')) {
                    $client->createDir('zcontainers');
                }

                $client->changeDir('zcontainers/');
            } else {
                $client->changeDir('zterminal/zcontainers/');
            }

            // Regular file upload

            echo 'INFO: Size ' . round($local_file_size / 1024 / 1024, 2) . "MB. Starting Code Upload\n";
            $remote_zip_path = basename($zip_path);
            $max_attempts = 10;
            $attempts = 0;
            
            // Checking whether the remote directory exists and removing it if necessary
            if ($compression_type == "tar") {
                $remote_directory = $tar_name . ".tar.gz";
            } else {
                $remote_directory = $zip_name;
            }

           
            if ($client->isFile($remote_directory)) {
                $client->removeFile($remote_directory);
            }
          
            // Attempting to upload the file with retry logic
            while ($attempts < $max_attempts) {
                if ($this->ftpUpload($client, $zip_path, $remote_zip_path)) {
                    break;
                }
            
                $attempts++;
                echo 'INFO: Attempting: ' . $attempts . PHP_EOL;
                sleep(5);
            }
            
            if ($attempts === $max_attempts) {
                return "ERROR: Upload; attempted " . $attempts;
            }
           

            echo "Finish Code Upload\n";

            $client->back();
            $remote_payload_name = 'quickDeploy.php';

            $payload_path = base_path() . '/storage/app/zterminal/payloads/' . $remote_payload_name;
            if (!$client->isExists('quickDeploy.php')) {
                if ($ftp_debug) {
                    echo "Uploading Payload\n";
                }
                if ($compression_type == "tar") {
                    $this->payloadBuilder($connection, $local_folders, $remote_payload_name, $ftp_core_folder, $tar_name . ".tar.gz", $server_project_directory);
                } else {
                    $this->payloadBuilder($connection, $local_folders, $remote_payload_name, $ftp_core_folder, $zip_name, $server_project_directory);
                }

                if ($client->isFile($remote_payload_name)) {
                    $client->removeFile($remote_payload_name);
                } 

                $client->upload($payload_path, $remote_payload_name);
                echo "Finish Payload Upload\n";
            } else {
                if ($ftp_debug) {
                    echo "Payload Found in Server\n";
                }
            }

            $connection->close();
            if ($ftp_debug) {
                echo "Closed FTP Connection\n";
            }


            echo $this->host_url . '/zterminal/quickDeploy.php';
            $response = Http::withOptions([
                'verify' => false,
            ])->get($this->host_url . '/zterminal/quickDeploy.php');

            echo "\n $response \n";

            echo 'Removing unnecessary files.';
            if (file_exists($payload_path)) {
                unlink($payload_path);
            }

            if (file_exists($zip_path)) {
                unlink($zip_path);
            }


            return Command::SUCCESS;
        } else {
            $this->error('Failed to connect to FTP server.');
        }
    }

    private function payloadBuilder($connection, $local_folders, $remote_payload_name, $ftp_core_folder, $zip_name, $server_project_directory)
    {
        $data['quickDeployWildcard'] = '?';
        $destinationPath = base_path() . '/storage/app/zterminal/payloads/';

        $serverZipData = view('system.zterminal.runner', compact('local_folders', 'data', 'remote_payload_name', 'ftp_core_folder', 'zip_name', 'server_project_directory'));
        if (!is_dir($destinationPath)) {
            mkdir($destinationPath, 0777, true);
        }

        File::put($destinationPath . $remote_payload_name, $serverZipData);
        return $destinationPath;
    }
 


    private function makeZip($local_folders, $backup_folder, $zip_name,$local_project_directory)
    {
        // Ensure ZipArchive is available
        if (!class_exists('ZipArchive')) {
            throw new Exception('ZipArchive class does not exist.');
        }

        $zip = new ZipArchive();
        $backup_path = \Storage::path($backup_folder);

        if (!is_dir($backup_path)) {
            mkdir($backup_path, 0755, true); // Consider more secure permissions
        }

        $zip_path = \Storage::path('zterminal/zips/' . $zip_name);

        if ($zip->open($zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === true) {
            foreach ($local_folders as $local_folder) {
                $this->addFolderToZip($zip, $local_folder, $local_project_directory);
            }

            $zip->close();
            return $zip_path;
        } else {
            throw new Exception("Could not open or create the zip file.");
        }
    }

    private function addFolderToZip($zip, $folder, $base_path, $relative_path = '')
    {
        $relative_path = $relative_path . DIRECTORY_SEPARATOR . $folder;

        $files = File::allFiles($base_path . DIRECTORY_SEPARATOR . $relative_path);

        foreach ($files as $file) {
            if ($file->getFilename() === '.' || $file->getFilename() === '..') {
                continue;
            }

            $relative_file_path = $relative_path . DIRECTORY_SEPARATOR . $file->getFilename();

            if (is_dir($file->getRealPath())) {
                $this->addFolderToZip($zip, $file->getFilename(), $base_path, $relative_file_path);
            } else {
                $zip->addFile($file->getRealPath(), $relative_file_path);
            }
        }
    }


    private function ftpUpload($client, $zip_path, $remote_zip_path)
    {
        try {
            $client->upload($zip_path, $remote_zip_path);
            return true;
        } catch (\Throwable $th) {
            return false;
        }
    }

    private function makeTar($directoryNames, $tarZipName, $basePath, $ftp_debug)
    {
        // Define the directory to store the tar file
        $tarDirectory = storage_path('app/zterminal/tars/');

        // Create the directory if it doesn't exist
        if (!is_dir($tarDirectory)) {
            mkdir($tarDirectory, 0755, true);
        }

        // Define the path for the tar file
        $tarZipPath = $tarDirectory . $tarZipName . '.tar.gz';

        // Build the tar command
        $tarCommand = "tar -czvf " . escapeshellarg($tarZipPath) . " -C " . escapeshellarg($basePath) . " " . implode(' ', array_map('escapeshellarg', $directoryNames));

        $output = shell_exec($tarCommand);
        
        // Check if the command executed successfully
        if ($output === null) {
            if ($ftp_debug) {
                echo "Tar command executed successfully!\n";
            }
        } else {
            // Throw an exception if there's an error
            throw new \Exception("Error executing tar command. Output: $output");
        }
        return $tarZipPath;
    }
}
