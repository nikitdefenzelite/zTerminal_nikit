<?php

namespace App\Console\Commands\zTerminal;

use Illuminate\Console\Command;

class Format extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'formate {action}';
    public $host_url, $ftp_host, $ftp_user, $ftp_password, $ftp_port, $ftp_folder, $host;
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'It deploy code in the specified server and make backup files available';

    public function handle()
    {
        
            $local_project_directory = "####LOCAL_PROJECT_DIRECTORY_PATH####";

        switch ($this->argument('action')) {
            case 'php':
                  $basePath = $local_project_directory;

                  $folders = ['app', 'database', 'config', 'lang', 'route'];

                  $phpcbfPath = $basePath . '/' . 'vendor/bin/phpcbf';

                  $standard = '--standard=PSR2';

            
                foreach ($folders as $folder) {

                    $command = "$phpcbfPath $standard $folder";
                     
                    echo "Running command: $command\n";
                    $output = shell_exec($command);

                    echo "$output\n";
                }
                break;
            default:
                break;
        }
    }
}
