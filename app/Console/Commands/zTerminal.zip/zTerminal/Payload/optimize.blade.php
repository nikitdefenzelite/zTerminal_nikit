<{{ $data['optimizewildcard'] }}php

class zOptimizeAgent
{
    // Helpers
    public function runOptimize($projectDirectory)
    {
        $output = null;
        $returnVar = null;

        $output = shell_exec("cd ".$projectDirectory ." && ". ' php artisan optimize:clear');
        return $output;
    }
}

// Config Items:
$deployerName = '{{getGitBranch() ?? 'dev'}}';
$projectPathDirectory = "{{$project_directory}}";
$projectPathDirectory = str_replace("&#039;", "'", $projectPathDirectory);
eval("\$dynamicPath = $projectPathDirectory;");
$projectDirectory = $dynamicPath;


$zOptimizeAgent = new zOptimizeAgent();

$response = $zOptimizeAgent->runOptimize($projectDirectory);

echo $response;

?>